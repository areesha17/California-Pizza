$(document).ready(function(){
    $('#success').modal('show');
    $(".flavor").click(function() {
        // Reset styling for all spans
        $("#flavorreq").css('background-color', '#198754');
    
        $('#flavorreq_error').css('visibility', 'hidden');
        $("#flavorreq").html("Selected");
    });
    $(".crust").click(function() {
        // Reset styling for all spans
        $("#crustreq").css('background-color', '#198754');
    
        $("#crustreq").html("Selected");
        $('#crustreq_error').css('visibility', 'hidden');
    });

    $(".drink").click(function() {
        // Reset styling for all spans
        $("#drinkreq").css('background-color', '#198754');
    
        $('#drinkreq_error').css('visibility', 'hidden');
        $("#drinkreq").html("Selected");
    });

    

});

function minus_qty(){
    var qty_b = parseInt($('#qtydisplay').html());
    var new_qty = qty_b - 1;
    if (new_qty <= 0){
        $('#qtydisplay').html('1');
        $('#qty_input').val(1);
    }else{
        $('#qtydisplay').html(new_qty);
        $('#qty_input').val(new_qty);
    }
}

function plus_qty(){
    var qty_b = parseInt($('#qtydisplay').html());
    var new_qty = qty_b + 1;
    if (new_qty <= 0){
        $('#qtydisplay').html('1');
        $('#qty_input').val(1);
    }else{
        $('#qtydisplay').html(new_qty);
        $('#qty_input').val(new_qty);
    }
}

function submitDetailsForm(e) {
    if (!$('.flavor:checked').length > 0) {
        $('#flavorreq_error').css('visibility', 'visible');
        $('#flavorreq_error')[0].scrollIntoView(); // Scroll to the error element
        e.preventDefault(); // Prevent form submission
    }
    if (!$('.crust:checked').length > 0) {
        $('#crustreq_error').css('visibility', 'visible');
        $('#crustreq_error')[0].scrollIntoView(); // Scroll to the error element
        e.preventDefault(); // Prevent form submission
    }
    if (!$('.drink:checked').length > 0) {
        $('#drinkreq_error').css('visibility', 'visible');
        $('#drinkreq_error')[0].scrollIntoView(); // Scroll to the error element
        e.preventDefault(); // Prevent form submission
    }else {
        var name = $("#name").val();
        var number = $("#number").val();
        var address = $("#address").val();

        if(name == ''){
            alert('Please Input Name');
        }
        if(number == ''){
            alert('Please Input Number');
        }
        if(address == ''){
            alert('Please Input Address');
        }else{
            $("#form").submit();
        }
        
    }
}


function deals(btn_id){
    if(btn_id == 1){
        $("#green_btn").text('Flash Deal')
    }
    if(btn_id == 2){
        $("#green_btn").text('World Cup Deals')
    }
    if(btn_id == 3){
        $("#green_btn").text('Pakistan ka Kabab Popper')
    }
    if(btn_id == 4){
        $("#green_btn").text('Crazy Offers')
    }
    if(btn_id == 5){
        $("#green_btn").text('Friendship Deals')
    }
    if(btn_id == 6){
        $("#green_btn").text('Crusts')
    }
    if(btn_id == 7){
        $("#green_btn").text('Discounted Deals')
    }
    if(btn_id == 8){
        $("#green_btn").text('Pizza')
    }
    if(btn_id == 9){
        $("#green_btn").text('Sides')
    }
    if(btn_id == 10){
        $("#green_btn").text('Drinks')
    }
    if(btn_id == 11){
        $("#green_btn").text('Desserts')
    }
}