
$(document).ready(function(){
    $('.customer-logos').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 1500,
    variableWidth: true,
    arrows: true,
    dots: false,
    pauseOnHover: false,
    prevArrow: '<i style="font-size: 75px; color:#cc2e2e;" class="slick-prev fa fa-angle-left"></i>',
    nextArrow: '<i style="font-size: 75px; color:#cc2e2e;" class="slick-next fa fa-angle-right"></i>',
    responsive: [{
      breakpoint: 768,
      settings: {
        slidesToShow: 3
      }
    }, {
      breakpoint: 520,
      settings: {
        slidesToShow: 2
      }
    }]
    });
  });