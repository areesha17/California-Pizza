<!-- The Modal -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">


            <!-- Modal body -->
            <div class="modal-body">
                <form action="<?=base_url()?>welcome/add_tocart" method="POST" id="form">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-5" style="border-right: 1px #00000038 solid;">
                                <img src="<?=base_url()?>assets/img/flash-deal.webp" class="img_radius1">
                            </div>
                            <div class="col-sm-7">
                                <div class="row">
                                    <div class="col-sm-10">
                                        <h3><b>Flash Deal 1</b></h3>
                                    </div>
                                    <div class="col-sm-2"
                                        style="display: flex;flex-direction: row-reverse;align-items: center;"><button
                                            type="button" data-bs-dismiss="modal" aria-label="Close"
                                            style="border: none;"><i class="fa fa-times"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>


                                <div class="row" style="overflow-y: scroll; height:400px;">
                                    <div class="col-sm-11">
                                        <h4><b>Rs. 899</b></h4>
                                        <h6 class="text-muted"><b>Regular pizza + small drink</b></h6>
                                        <div class="row" style="margin-top: 20px;">
                                            <div class="col-sm-10">
                                                <h5 style="margin-left:20px"><b>Choose Meaty Flavor</b></h5>
                                            </div>
                                            <div class="col-sm-2">
                                                <span class="badge badge-warning" id="flavorreq"
                                                    style="background-color:#ffc107;">Required</span>
                                            </div>

                                            <div class="col-sm-10" style="visibility: hidden;" id="flavorreq_error">
                                                <p style="margin-left:20px;color:red;">You must select at least one
                                                    addon - Choose Meaty Flavor</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="MaryLand Delight" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> MaryLand Delight</h6>
                                                <p>Jamaican Chicken, Capsicum, Red Jalapenos, Chaska Sauce & Cheese</p>
                                            </div>
                                            <div class="col-sm-2">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="Mexican Treat" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Mexican Treat</h6>
                                                <p>Chicken Tikka topped with Onions & Cheese</p>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center; ">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="Miami Beast" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Miami Beast</h6>
                                                <p>Chicken Fajita with Green Jalapenos, Green Peppers, Onions & Cheese
                                                </p>
                                            </div>
                                            <div class="col-sm-2">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="Chicago Bulls" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Chicago Bulls</h6>
                                                <p>Chicken Tikka with Onions, Mushrooms, Garlic Sauce & Cheese</p>
                                            </div>
                                            <div class="col-sm-2">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="Ohio Thrill" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted">Ohio Thrill</h6>
                                                <p>Jamaican Chicken, Onions, Capsicum, Red & Green Jalapenos, Chipotle
                                                    Sauce
                                                    & Cheese </p>
                                            </div>
                                            <div class="col-sm-2">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="Detroit Pepperoni" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Detroit Pepperoni</h6>
                                                <p>Mozzarella Cheese Loaded with Pepperoni</p>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/Detroitlar.jpeg"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <p>Rs. 100</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input flavor" type="radio" name="flavor"
                                                        value="Florida Feast" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Florida Feast</h6>
                                                <p>Chicken Fajita topped with Onions, Black Olives, Ranch Sauce & Cheese
                                                </p>
                                            </div>
                                            <div class="col-sm-2">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <p>Rs. 100</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 20px;">
                                            <div class="col-sm-10">
                                                <h5 style="margin-left:20px"><b>Choose Your Crust For Regular Pizza</b>
                                                </h5>
                                            </div>
                                            <div class="col-sm-2">
                                                <span class="badge badge-warning" id="crustreq"
                                                    style="background-color:#ffc107;">Required</span>
                                            </div>
                                            <div class="col-sm-10" style="visibility: hidden;" id="crustreq_error">
                                                <p style="margin-left:20px;color:red;">You must select at least one
                                                    addon - Choose Your Crust Flavors</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input crust" type="radio" name="crust"
                                                        value="Deep Pan" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted">Deep Pan</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/MiamiBeast.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input crust" type="radio" name="crust"
                                                        value="Thin Crust" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted">Thin Crust</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/thin-crust.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input crust" type="radio" name="crust"
                                                        value="Kabab Popper" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Kabab Popper</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/Kabab-popper.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <p>Rs. 200</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input crust" type="radio" name="crust"
                                                        value="Stuffed Crust" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted">Stuffed Crust</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/Kabab-popper.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <p>Rs. 200</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 20px;">
                                            <div class="col-sm-10">
                                                <h5 style="margin-left:20px"><b>Select Your Drink</b></h5>
                                            </div>
                                            <div class="col-sm-2">
                                                <span class="badge badge-warning" id="drinkreq"
                                                    style="background-color:#ffc107;">Required</span>
                                            </div>
                                            <div class="col-sm-10" style="visibility: hidden;" id="drinkreq_error">
                                                <p style="margin-left:20px;color:red;">You must select at least one
                                                    addon - Choose your Drink</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input drink" type="radio" name="drink"
                                                        value="Coke" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted">Coke</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/coke.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <i class="fa fa-minus" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input drink" type="radio" name="drink"
                                                        value="Sprite" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted"> Sprite</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/sprite.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <p>Rs. 100</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 10px;border-bottom: 1px #0000002e solid;">
                                            <div class="col-sm-1">
                                                <div class="form-check">
                                                    <input class="form-check-input drink" type="radio" name="drink"
                                                        value="Fanta" id="flexRadioDefault1"
                                                        style="border:2px solid rgb(0 0 0 / 58%)">
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <h6 class="text-muted">Fanta</h6>
                                            </div>
                                            <div class="col-sm-2" style="margin-bottom:12px">
                                                <img src="<?=base_url()?>assets/img/flash-deal/fanta.webp"
                                                    class="img_radius1">
                                            </div>
                                            <div class="col-sm-3"
                                                style="display: flex;flex-direction: row-reverse;align-items: center;">
                                                <p>Rs. 100</p>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 20px; margin-bottom:20px;">
                                            <div class="col-sm-12">
                                                <h5 style="margin-left:20px"><b>Special Instructions</b></h5>
                                                <textarea class="form-control" rows="3" id="comment"
                                                    placeholder="Please enter intructions about this item if any."
                                                    name="instruction"></textarea>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <label for="name">Name:</label>
                                                        <input type="text" class="form-control" name="name" id="name" required>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label for="number">Number:</label>
                                                        <input type="text" class="form-control" name="number" id="number" required>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <label for="number">Address:</label>
                                                        <input type="text" class="form-control" name="address" id="address" required>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <div class=" col-sm-6 offset-sm-6">
                            <div class="row">
                                <div class="col-sm-1">
                                    <button type="button" onclick="minus_qty()" class="btn btn-danger"
                                        style="border-radius: 15px;"><i class="fa fa-minus"
                                            aria-hidden="true"></i></button>
                                </div>
                                <div class="col-sm-1">
                                    <h4><b id="qtydisplay">1</b></h4>
                                    <input type="hidden" name="qty" id="qty_input" value="1">
                                </div>
                                <div class="col-sm-1">
                                    <button type="button" onclick="plus_qty()" class="btn btn-danger"
                                        style="border-radius: 15px;"><i class="fa fa-plus"
                                            aria-hidden="true"></i></button>
                                </div>
                                <div class="col-sm-9">
                                    <button type="button" onClick='submitDetailsForm()' class="btn btn-danger bg_red"
                                        style="width: 100%;">Add To Cart - Rs. 899</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>