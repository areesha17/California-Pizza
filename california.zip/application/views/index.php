<!DOCTYPE html>
<html lang="en">

<?php
 include('header.php');
//  include('popup.php');
?>
<body>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="<?=base_url()?>assets/js/customslick.js"></script>
<script src="<?=base_url()?>assets/js/index.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
    <!-- included header.php -->

</script>
<style>
    /* width */
::-webkit-scrollbar {
  width: 10px;
  height: 25px;
}

    /* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: red !important; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #b30000; 
}
</style>
    <div id="demo" class="carousel slide" data-bs-ride="carousel" style="margin: 0px !important;">

        <!-- Indicators/dots -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
        </div>
        
        <!-- The slideshow/carousel -->
        <div class="carousel-inner">
            <div class="carousel-item active">
            <img src="<?=base_url()?>assets/img/banner1.webp" alt="Los Angeles" class="d-block" style="width:100%">
            </div>
            <div class="carousel-item">
            <img src="<?=base_url()?>assets/img/banner2.webp" alt="Chicago" class="d-block" style="width:100%">
            </div>
            <div class="carousel-item">
            <img src="<?=base_url()?>assets/img/banner3.webp" alt="New York" class="d-block" style="width:100%">
            </div>
        </div>
        
        <!-- Left and right controls/icons -->
        <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>

    <!-- brand Slider -->
    <section class="trigger section gutter-horizontal bg-gray gutter-vertical--m gutter-horizontal" style="max-width: 100%;">
        <div class="customer-logos slider">
            <a class="redhover" ><div class="slide-in-right slide"><img class="slider_images img_radius1" src="<?=base_url()?>assets/img/submenu/1.webp" >Card Discount</div></a>
            <a class="redhover" ><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/2.webp"  class="slider_images img_radius1">JazzCash Deals</div></a>
            <a class="redhover" onclick="deals(1)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/flash_deal.webp"  class="slider_images img_radius1">Flash deal</div></a>
            <a class="redhover" onclick="deals(3)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/5.webp"  class="slider_images img_radius1">Pakistan ka <br>Kabab Popper</div></a>
            <a class="redhover" onclick="deals(4)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/6.webp"  class="slider_images img_radius1">Crazy Offers</div></a>
            <a class="redhover" onclick="deals(5)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/7.webp"  class="slider_images img_radius1">Friendship <br> Deals</div></a>
            <a class="redhover" onclick="deals(6)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/8.webp"  class="slider_images img_radius1">Crusts</div></a>
            <a class="redhover" onclick="deals(7)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/9.webp"  class="slider_images img_radius1">Discounted <br> Deals</div></a>
            <a class="redhover" onclick="deals(8)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/10.webp"  class="slider_images img_radius1">Pizza</div></a>
            <a class="redhover" onclick="deals(9)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/11.webp"  class="slider_images img_radius1">Sides</div></a>
            <a class="redhover" onclick="deals(10)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/12.webp"  class="slider_images img_radius1">Drinks</div></a>
            <a class="redhover" onclick="deals(11)"><div class="slide-in-right slide"><img src="<?=base_url()?>assets/img/submenu/13.webp"  class="slider_images img_radius1">Desserts</div></a>
        </div>
        <div class="col-md-12 btn_green_div">
            <button class="green_btn" id="green_btn">Flash Deal</button>
        </div>  
    </section>
    <section style="padding-bottom: 20px;margin-top: 30px;">
    <div class="col-md-12">
        <div class="col-sm-12" style="display:flex;justify-content: space-around;">
            <h2 class="fw-600">Flash Deal</h2>
        </div>
        <div class="col-md-12">
            <div class="container">
                <div class="col-sm-4">
                    <img src="<?=base_url()?>assets/img/flash-deal.webp" class="img_radius" style="height: 300px;">
                    <h5 style="margin-top: 30px;
                                color: rgb(33, 37, 41);" class="ml-8 fw-800">Flash Deal 1</h5>
                    <p class="text-muted ml-8" style="font-size: 12px;">Regular pizza + small drink</p>
                    <p class="ml-8 fw-800" style="font-size: .8rem;"><b>Rs. 899</b></p>
                    <button  class="btn btn-danger ml-8 bg_red add-cart" style="margin-bottom: 20px;" type="button" data-bs-toggle="modal" data-bs-target="#myModal">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        <b>Add to Cart</b>
                </button>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <img src="<?=base_url()?>assets/img/flash-deal.webp" class="img_radius" style="height: 300px;">
                        <h5 style="margin-top: 30px;
                                    color: rgb(33, 37, 41);" class="ml-8 fw-800">Flash Deal 1</h5>
                        <p class="text-muted ml-8" style="font-size: 12px;">Regular pizza + small drink</p>
                        <p class="ml-8 fw-800" style="font-size: .8rem;"><b>Rs. 899</b></p>
                        <button type="button" class="btn btn-danger ml-8 bg_red add-cart" style="margin-bottom: 20px;" data-bs-toggle="modal" data-bs-target="#myModal">
                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            <b>Add to Cart</b>
                        </button>
                    </div>
                    <div class="col-sm-4">
                        <img src="<?=base_url()?>assets/img/flash-deal.webp" class="img_radius" style="height: 300px;">
                        <h5 style="margin-top: 30px;
                                    color: rgb(33, 37, 41);" class="ml-8 fw-800">Flash Deal 1</h5>
                        <p class="text-muted ml-8" style="font-size: 12px;">Regular pizza + small drink</p>
                        <p class="ml-8 fw-800" style="font-size: .8rem;"><b>Rs. 899</b></p>
                        <button type="button" class="btn btn-danger ml-8 bg_red add-cart" style="margin-bottom: 20px;" data-bs-toggle="modal" data-bs-target="#myModal">
                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            <b>Add to Cart</b>
                        </button>
                    </div>
                    <div class="col-sm-4">
                        <img src="<?=base_url()?>assets/img/flash-deal.webp" class="img_radius" style="height: 300px;">
                        <h5 style="margin-top: 30px;
                                    color: rgb(33, 37, 41);" class="ml-8 fw-800">Flash Deal 1</h5>
                        <p class="text-muted ml-8" style="font-size: 12px;">Regular pizza + small drink</p>
                        <p class="ml-8 fw-800" style="font-size: .8rem;"><b>Rs. 899</b></p>
                        <button type="button" class="btn btn-danger ml-8 bg_red add-cart" style="margin-bottom: 20px;" data-bs-toggle="modal" data-bs-target="#myModal">
                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            <b>Add to Cart</b>
                        </button>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="col-sm-12" style="display: flex;justify-content: flex-end;">
            <button type="button" id="next" class="btn btn-danger ml-8 bg_red nexpre">
                <b>Next</b>
            </button>
        </div>
    </div>
    </section>
<?php
 if(isset($flag)){
    if($flag){
?>
    <div id="success" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                
                <div class="modal-body">
                    <div class="alert alert-success" role="alert">
                        <p>Your order has been placed, please hold</p>
                    </div>
                </div>
              
            </div>

        </div>
    </div>
<?php
    }
 }
?>
    <section style="margin-bottom: 30px;">
        <div class="col-sm-12">
            <div class="container" style="display: flex;justify-content: center;">
                <div class="col-sm-8">
                    <h1 style="color: #494545;">California Pizza: A Culinary Journey to Pizza Paradise Across Cities</h1>
                    <p class="text-muted">
                        Treat your senses with the culinary delights of California Pizza, proudly serving the most mouthwatering 
                        pizzas across Karachi, Lahore, Islamabad, Multan, Hyderabad, and Rawalpindi. We are your ultimate destination 
                        for an unforgettable pizza experience, offering a diverse menu that caters to every palate. From the sumptuous 
                        flavors of our Lasagna to the delightfully cheesy goodness of our Large Pizza in Karachi, we have perfected the 
                        art of crafting pizzas that leave a lasting impression.
                    </p>
                    <p class="text-muted">
                        Explore our Mexican Sandwich Deal in Karachi, a tantalizing fusion of flavors that transports you to a world of 
                        culinary ecstasy. Craving the best pizza in Lahore? Look no further - our online pizza menu in Lahore showcases a 
                        symphony of taste that's bound to satisfy even the most discerning pizza enthusiast. Discover the essence of California 
                        Pizza through glowing California Pizza Reviews, a testament to our commitment to excellence and customer satisfaction.
                    </p>
                    <p class="text-muted">
                        Experience the ultimate indulgence with our top delivery deals in Pakistan, offering a variety of options to elevate your 
                        dining experience. Whether you're a devoted Pizza Lover or a Veggie Lover at heart, our array of Best Pizza Flavors caters 
                        to all preferences. For the little ones, our Pizza Kids Meal is a perfect treat, providing a Best Kids Meal that mirrors 
                        the quality and taste that defines California Pizza.
                    </p>
                    <p class="text-muted">
                        Step into the realm of flavor innovation as we redefine pizza perfection with every slice. Our Chicken Pasta Deal in 
                        Karachi is a harmony of taste and texture, embodying the essence of California Pizza's culinary artistry. As one of the 
                        best pizza shops in the region, we take immense pride in delivering an exceptional taste that resonates with every bite. 
                        Discover the true essence of gourmet pizza, only at California Pizza, where every pizza crafted is a masterpiece that delights 
                        the senses and captures the heart.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <?php
    include('footer.php');
    ?>
    <?php
    include('add_tocart.php');
    ?>
    


   
    
</body>

</html>