<!-- Footer -->
<footer class="bg-black text-center text-white">
    <!-- Grid container -->
    <div class="container p-4">
        <!-- Section: Social media -->
        <section class="mb-4">
            <!-- Facebook -->
            <div>
                <img src="<?=base_url()?>assets/img/google-play.webp">
                <img src="<?=base_url()?>assets/img/app-store.webp">
            </div>
            <div style="margin-top: 10px;">
                <i style="font-size: 28px; margin-right: 5px;" class="fa fa-facebook"></i>
                <i style="font-size: 28px;" class="fa fa-instagram"></i>
            </div>
            <div style="margin-top: 10px;">
                <img src="<?=base_url()?>assets/img/visa.webp" style="height: 50px;">
            </div>
            <div style="margin-top: 10px;">
                <span style="font-weight: 700; font-size: 25px;">POWERED Areesha | Terms & Services | Privacy Policy | FAQS | Blog</span>
            </div>


        </section>
    </div>
</footer>
<!-- Footer -->