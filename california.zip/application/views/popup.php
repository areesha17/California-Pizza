<!-- Modal -->
<style>
</style>
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <img src="<?=base_url()?>assets/img/popup.webp" style="width: 100%;">
        </div>

    </div>
</div>