<!DOCTYPE html>
<html lang="en">
<head>
  <title>Californa DB</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>California Pizza DB</h2>
  <a class="btn btn-danger" style="float: right;" href="<?=base_url()?>welcome/logout">Logout</a>
  <p>All Orders for today</p>            
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Order #</th>
        <th>Name</th>
        <th>Number</th>
        <th>Address</th>
        <th>Flavor</th>
        <th>Crust</th>
        <th>Drink</th>
        <th>Instruction</th>
        <th>Qty</th>
      </tr>
    </thead>
    <tbody>
      <?php
        foreach ($datas as $data) {
      ?>
        <tr>
            <td><?=$data['id']?></td>
            <td><?=$data['name']?></td>
            <td><?=$data['number']?></td>
            <td><?=$data['address']?></td>
            <td><?=$data['flavor']?></td>
            <td><?=$data['crust']?></td>
            <td><?=$data['drink']?></td>
            <td><?=$data['instruction']?></td>
            <td><?=$data['qty']?></td>
        </tr>
      <?php
        }
      ?>
    </tbody>
  </table>
</div>

</body>
</html>
