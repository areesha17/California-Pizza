<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Add_tocart_model extends CI_Model {


  public function login($uname,$pass)
  {
    $this->db->from('admin');
    $this->db->where('username', $uname); // Replace $email with the email value you're checking
    $this->db->where('pass', $pass); // Replace $password with the password value you're checking

    return $this->db->count_all_results();
  }
  public function insert_order($input){
    $this->db->insert('order',$input);
    return true;
  }
  public function orders(){
    return $this->db->get('order')->result_array();
  }

  // ------------------------------------------------------------------------

}

/* End of file Add_tocart_model.php */
/* Location: ./application/models/Add_tocart_model.php */