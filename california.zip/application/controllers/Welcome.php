<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *  @property CI_Input $input
 *  @property Add_tocart_model $ATC
 *  @property session_class $session
 */

class Welcome extends CI_Controller {
	
	public function __construct()
    {
        parent::__construct();
        $this->load->model("Add_tocart_model", 'ATC');
    }
	public function index()
	{
		$this->load->view('index');
	}

	public function add_tocart(){
		$input = $this->input->post();
		$flag['flag'] = $this->ATC->insert_order($input);
		$this->load->view('index',$flag);
		
	}

	public function login_view(){
		$this->load->view('login');
	}

	public function login(){
		$user = $this->input->post('user');  
        $pass = $this->input->post('pass');

		$count = $this->ATC->login($user,$pass);



        if($count==1)   
        {  
            //declaring session  
            $this->session->set_userdata(array('user'=>$user));  
            redirect("Welcome/form");
        }  
        else{  
            $data['error'] = true;  
            $this->load->view('login', $data);  
        }  
	}
	public function form(){

		
		if (isset($_SESSION['user'])) {
			$data['datas'] = $this->ATC->orders();
		$this->load->view('form',$data); 
		}else{
			redirect("Welcome/login_view");
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect("Welcome/login_view");
	}
}